/**
 * Presentation and Gesture data types for GesturePilot AI
 */

export type GestureType =
  | 'NONE'
  | 'OPEN_PALM'
  | 'V_SIGN'
  | 'THUMBS_UP'
  | 'CLOSED_FIST'
  | 'INDEX_POINTING_UP'
  | 'NEUTRAL';

export interface GestureDefinition {
  type: GestureType;
  name: string;
  action: string;
  symbol: string;
  description: string;
  fingerRule: string;
}

export const GESTURE_DEFINITIONS: Record<GestureType, GestureDefinition> = {
  OPEN_PALM: {
    type: 'OPEN_PALM',
    name: 'Open Palm',
    action: 'Next Slide / Page',
    symbol: '✋',
    description: 'All 5 fingers extended outward and open',
    fingerRule: 'Index, middle, ring, and pinky extended; palm open',
  },
  V_SIGN: {
    type: 'V_SIGN',
    name: 'V Sign (Peace)',
    action: 'Previous Slide / Page',
    symbol: '✌️',
    description: 'Index and middle fingers extended in a V shape',
    fingerRule: 'Index & middle up; ring, pinky & thumb curled',
  },
  THUMBS_UP: {
    type: 'THUMBS_UP',
    name: 'Thumbs Up',
    action: 'Enter Presentation Mode',
    symbol: '👍',
    description: 'Thumb pointing upward with fist closed',
    fingerRule: 'Thumb pointing up; all four fingers curled in fist',
  },
  CLOSED_FIST: {
    type: 'CLOSED_FIST',
    name: 'Closed Fist',
    action: 'Exit Presentation Mode',
    symbol: '✊',
    description: 'All fingers curled tightly into a fist',
    fingerRule: 'All fingers and thumb closed against palm',
  },
  INDEX_POINTING_UP: {
    type: 'INDEX_POINTING_UP',
    name: 'Index Finger Up',
    action: 'Toggle Black Screen',
    symbol: '☝️',
    description: 'Only the index finger extended upward',
    fingerRule: 'Index up; thumb, middle, ring, pinky folded',
  },
  NEUTRAL: {
    type: 'NEUTRAL',
    name: 'Neutral Pose',
    action: 'Standby / Latch Release',
    symbol: '🤚',
    description: 'Hand resting or transitioning between gestures',
    fingerRule: 'Release gesture to re-arm recognition',
  },
  NONE: {
    type: 'NONE',
    name: 'No Hand Detected',
    action: 'Idle',
    symbol: '🔍',
    description: 'Waiting for hand in camera frame',
    fingerRule: 'Place hand in view of webcam',
  },
};

export type DocumentType = 'demo' | 'pdf' | 'pptx';

export interface DemoSlideContent {
  title: string;
  subtitle?: string;
  category?: string;
  points?: {
    heading: string;
    description: string;
    icon?: string;
  }[];
  cards?: {
    title: string;
    description: string;
    badge?: string;
    symbol?: string;
  }[];
  footerNote?: string;
  layout: 'title' | 'problem' | 'solution' | 'workflow';
}

export interface PptxShape {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  text?: string;
  paragraphs?: {
    text: string;
    fontSize?: number;
    bold?: boolean;
    italic?: boolean;
    color?: string;
    align?: 'left' | 'center' | 'right';
    isBullet?: boolean;
  }[];
  fillColor?: string;
  borderColor?: string;
  isImage?: boolean;
  imageUrl?: string;
  shapeType?: 'rect' | 'text' | 'image' | 'table';
  tableRows?: string[][];
}

export interface PptxSlideData {
  slideNumber: number;
  width: number;
  height: number;
  backgroundColor: string;
  shapes: PptxShape[];
  title?: string;
  notes?: string;
}

export interface SlideItem {
  id: string;
  index: number;
  slideNumber: number; // 1-based
  type: DocumentType;
  title?: string;
  demoData?: DemoSlideContent;
  pptxData?: PptxSlideData;
  pdfPageIndex?: number; // 0-based for pdfjs
}

export interface PresentationDocument {
  id: string;
  fileName: string;
  fileType: DocumentType;
  totalSlides: number;
  slides: SlideItem[];
  fileSize?: number;
  pdfDoc?: any; // PDFDocumentProxy instance
  rawArrayBuffer?: ArrayBuffer;
  createdAt: number;
}

export interface GestureDetectionState {
  detectedGesture: GestureType;
  activeGesture: GestureType;
  confidence: number;
  holdProgress: number; // 0.0 to 1.0
  isHolding: boolean;
  isInCooldown: boolean;
  cooldownProgress: number; // 0.0 to 1.0
  waitingForNeutralRelease: boolean;
  handInView: boolean;
  lastTriggeredGesture: GestureType | null;
  lastTriggeredTime: number;
}
