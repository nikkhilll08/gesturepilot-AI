import { PresentationDocument, SlideItem } from '../types/presentation';

export function createDemoPresentation(): PresentationDocument {
  const slides: SlideItem[] = [
    {
      id: 'demo-slide-1',
      index: 0,
      slideNumber: 1,
      type: 'demo',
      title: 'GesturePilot AI',
      demoData: {
        layout: 'title',
        category: 'Next-Generation Presentation Control',
        title: 'GesturePilot AI',
        subtitle: 'Touchless Five-Gesture Presentation Controller',
        points: [
          {
            heading: 'Zero-Hardware Control',
            description: 'Turn standard webcams into precision presentation clickers with zero companion apps or plugins.',
          },
          {
            heading: 'Sub-60ms Computer Vision',
            description: 'High-fidelity 21-point hand landmark tracking running directly in modern web browsers.',
          },
          {
            heading: 'Local & Private',
            description: 'Video frames stay strictly inside local browser memory. No cloud processing or recording.',
          },
        ],
        footerNote: 'Engineered for smooth keynote and lecture presentations without podium confinement.',
      },
    },
    {
      id: 'demo-slide-2',
      index: 1,
      slideNumber: 2,
      type: 'demo',
      title: 'Problem Statement',
      demoData: {
        layout: 'problem',
        category: 'Presenter Friction & Bottlenecks',
        title: 'The Challenge With Traditional Presenting',
        subtitle: 'Physical clickers and awkward laptop controls break presenter flow and audience connection.',
        cards: [
          {
            title: 'Hardware Fragility',
            badge: 'Reliability Issue',
            description: 'Clickers require USB dongles, Bluetooth pairing, and fresh AAA batteries that fail at critical moments.',
            symbol: '🔌',
          },
          {
            title: 'Podium Confinement',
            badge: 'Restricted Mobility',
            description: 'Presenters are chained to their laptop keyboard or podium, losing natural stage presence and eye contact.',
            symbol: '🔒',
          },
          {
            title: 'Audience Disconnection',
            badge: 'Engagement Loss',
            description: 'Awkward pauses while searching for buttons or turning around to look at the screen disrupts the audience.',
            symbol: '📉',
          },
          {
            title: 'Software Clutter',
            badge: 'Complex Setup',
            description: 'Legacy tools demand proprietary desktop software, administrative permissions, or mobile companion apps.',
            symbol: '⚙️',
          },
        ],
        footerNote: 'Speakers need seamless, natural control that feels invisible to the audience.',
      },
    },
    {
      id: 'demo-slide-3',
      index: 2,
      slideNumber: 3,
      type: 'demo',
      title: 'Proposed Solution',
      demoData: {
        layout: 'solution',
        category: 'Intelligent Vision Interface',
        title: 'Natural Hand Gesture Orchestration',
        subtitle: 'A deterministic 5-gesture system engineered for ergonomic, mistake-free slide delivery.',
        cards: [
          {
            title: '100% In-Browser Vision',
            badge: 'Zero Install',
            description: 'Runs entirely client-side using MediaPipe neural hand landmark mesh. Works out of the box in any modern browser.',
            symbol: '⚡',
          },
          {
            title: 'Orthogonal Gesture Grammar',
            badge: 'Mistake-Proof',
            description: 'Five distinct hand postures with strict 600ms hold stabilization and 800ms cooldown to eliminate accidental triggers.',
            symbol: '🎯',
          },
          {
            title: 'Instant Black Screen Focus',
            badge: 'Presenter Tool',
            description: 'Index-finger pointing immediately blacks out the canvas to redirect audience attention back to the speaker.',
            symbol: '🌑',
          },
          {
            title: 'Universal Document Engine',
            badge: 'Any Format',
            description: 'Native parsing and high-DPI rendering for both PowerPoint (.pptx) and PDF presentations.',
            symbol: '📄',
          },
        ],
        footerNote: 'No specialized hardware. No cloud dependencies. Just natural presenting.',
      },
    },
    {
      id: 'demo-slide-4',
      index: 3,
      slideNumber: 4,
      type: 'demo',
      title: 'How It Works',
      demoData: {
        layout: 'workflow',
        category: 'Workflow & Five-Gesture Guide',
        title: 'How It Works: Five Hand Gestures',
        subtitle: 'Choose a presentation, view slides, and control them using five hand gestures.',
        cards: [
          {
            title: 'Open Palm',
            badge: 'Next Slide',
            description: 'Open hand with all fingers extended. Advances to the next slide or PDF page.',
            symbol: '✋',
          },
          {
            title: 'V Sign (Peace)',
            badge: 'Previous Slide',
            description: 'Index & middle fingers extended in a V. Returns to the previous slide or page.',
            symbol: '✌️',
          },
          {
            title: 'Thumbs Up',
            badge: 'Enter Presentation',
            description: 'Thumb pointing upward with closed fist. Enters immersive full-screen presentation mode.',
            symbol: '👍',
          },
          {
            title: 'Closed Fist',
            badge: 'Exit Presentation',
            description: 'Fingers folded into a tight fist. Exits presentation mode back to standard view.',
            symbol: '✊',
          },
          {
            title: 'Index Finger Up',
            badge: 'Toggle Black Screen',
            description: 'Only index finger pointed up. Blacks screen; repeat after neutral release to restore slide.',
            symbol: '☝️',
          },
        ],
        footerNote: 'Each gesture requires ~600ms steady hold. A neutral release is required between actions.',
      },
    },
  ];

  return {
    id: 'demo-gesturepilot',
    fileName: 'GesturePilot-AI-Demo.pptx',
    fileType: 'demo',
    totalSlides: 4,
    slides,
    createdAt: Date.now(),
  };
}
