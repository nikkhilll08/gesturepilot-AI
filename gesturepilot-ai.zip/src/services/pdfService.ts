import * as pdfjsLib from 'pdfjs-dist';
import { PresentationDocument, SlideItem } from '../types/presentation';

// Configure worker
if (typeof window !== 'undefined') {
  // Use official CDN worker matching pdfjsLib version or cdnjs
  try {
    const version = pdfjsLib.version || '4.10.38';
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${version}/pdf.worker.min.mjs`;
  } catch {
    // Worker fallback
  }
}

export async function parsePdfFile(file: File | ArrayBuffer, fileName: string): Promise<PresentationDocument> {
  const arrayBuffer = file instanceof File ? await file.arrayBuffer() : file;

  try {
    const loadingTask = pdfjsLib.getDocument({
      data: new Uint8Array(arrayBuffer),
      useWorkerFetch: false,
      useSystemFonts: true,
    });

    const pdfDoc = await loadingTask.promise;
    const numPages = pdfDoc.numPages;

    if (numPages <= 0) {
      throw new Error('The PDF document contains 0 pages.');
    }

    const slides: SlideItem[] = [];
    for (let i = 1; i <= numPages; i++) {
      slides.push({
        id: `pdf-page-${i}`,
        index: i - 1,
        slideNumber: i,
        type: 'pdf',
        title: `Page ${i}`,
        pdfPageIndex: i,
      });
    }

    return {
      id: `pdf-${Date.now()}`,
      fileName: fileName || 'Document.pdf',
      fileType: 'pdf',
      totalSlides: numPages,
      slides,
      pdfDoc,
      rawArrayBuffer: arrayBuffer,
      createdAt: Date.now(),
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown PDF error';
    throw new Error(`Failed to load PDF presentation: ${message}`);
  }
}

export async function renderPdfPageToCanvas(
  pdfDoc: any,
  pageNumber: number,
  canvas: HTMLCanvasElement,
  targetWidth?: number
): Promise<void> {
  if (!pdfDoc || !canvas) return;

  try {
    const page = await pdfDoc.getPage(pageNumber);
    const unscaledViewport = page.getViewport({ scale: 1 });

    const dpr = window.devicePixelRatio || 1;
    const containerWidth = targetWidth || canvas.parentElement?.clientWidth || 1200;
    const scale = (containerWidth / unscaledViewport.width) * Math.min(dpr, 2.5);

    const viewport = page.getViewport({ scale });

    canvas.width = viewport.width;
    canvas.height = viewport.height;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.objectFit = 'contain';

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const renderContext = {
      canvasContext: ctx,
      viewport: viewport,
    };

    await page.render(renderContext).promise;
  } catch (err) {
    // Ignore render cancellations
  }
}

/**
 * Creates a valid, clean sample 4-page PDF document for immediate testing
 */
export async function createSamplePdf(): Promise<File> {
  // Minimal valid PDF binary with 4 distinct pages
  const content = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R 4 0 R 5 0 R 6 0 R] /Count 4 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 7 0 R /Resources << /Font << /F1 11 0 R >> >> >>
endobj
4 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 8 0 R /Resources << /Font << /F1 11 0 R >> >> >>
endobj
5 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 9 0 R /Resources << /Font << /F1 11 0 R >> >> >>
endobj
6 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 10 0 R /Resources << /Font << /F1 11 0 R >> >> >>
endobj
7 0 obj
<< /Length 205 >>
stream
BT
/F1 28 Tf
72 700 Td
(GesturePilot AI - Real PDF Deck) Tj
/F1 14 Tf
0 -40 Td
(Page 1 of 4: Touchless Presentation Controller) Tj
0 -30 Td
(- Fully parsed and rendered by PDF.js engine) Tj
0 -25 Td
(- Use Open Palm for Next Page, V Sign for Previous) Tj
ET
endstream
endobj
8 0 obj
<< /Length 195 >>
stream
BT
/F1 26 Tf
72 700 Td
(PDF Page 2: Hand Gesture Precision) Tj
/F1 14 Tf
0 -40 Td
(Testing Five Distinct Webcam Hand Gestures:) Tj
0 -30 Td
(1. Open Palm -> Next Page) Tj
0 -25 Td
(2. V Sign -> Previous Page) Tj
0 -25 Td
(3. Thumbs Up -> Fullscreen Mode) Tj
ET
endstream
endobj
9 0 obj
<< /Length 210 >>
stream
BT
/F1 26 Tf
72 700 Td
(PDF Page 3: Reversible Black Screen) Tj
/F1 14 Tf
0 -40 Td
(Index Finger Pointing Up Mode:) Tj
0 -30 Td
(- Hold index finger up for ~600ms to toggle black screen) Tj
0 -25 Td
(- Repeating gesture restores this exact page intact) Tj
0 -25 Td
(- Cooldown prevents accidental multiple triggers) Tj
ET
endstream
endobj
10 0 obj
<< /Length 190 >>
stream
BT
/F1 26 Tf
72 700 Td
(PDF Page 4: Summary & Exit) Tj
/F1 14 Tf
0 -40 Td
(Presentation Ready) Tj
0 -30 Td
(- Closed Fist exits presentation mode) Tj
0 -25 Td
(- True page count verified: exactly 4 pages) Tj
0 -25 Td
(- Complete privacy: local browser processing) Tj
ET
endstream
endobj
11 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 12
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000133 00000 n 
0000000257 00000 n 
0000000381 00000 n 
0000000505 00000 n 
0000000629 00000 n 
0000000887 00000 n 
0000001135 00000 n 
0000001398 00000 n 
0000001641 00000 n 
trailer
<< /Size 12 /Root 1 0 R >>
startxref
1718
%%EOF`;

  return new File([content], 'Sample-Presentation-Document.pdf', {
    type: 'application/pdf',
  });
}
