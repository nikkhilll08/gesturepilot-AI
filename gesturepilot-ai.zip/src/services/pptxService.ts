import JSZip from 'jszip';
import { PresentationDocument, SlideItem, PptxSlideData, PptxShape } from '../types/presentation';

// Default EMU dimensions for 16:9 presentation (1920x1080 approx in EMUs)
const DEFAULT_WIDTH_EMU = 12192000;
const DEFAULT_HEIGHT_EMU = 6858000;

export async function parsePptxFile(file: File | ArrayBuffer, fileName: string): Promise<PresentationDocument> {
  const arrayBuffer = file instanceof File ? await file.arrayBuffer() : file;
  let zip: JSZip;

  try {
    zip = await JSZip.loadAsync(arrayBuffer);
  } catch (err) {
    throw new Error('Unable to read file as a PowerPoint presentation. The file may be corrupt or encrypted.');
  }

  // Verify PPTX structure
  const presFile = zip.file('ppt/presentation.xml');
  if (!presFile) {
    throw new Error('Invalid PowerPoint file: "ppt/presentation.xml" not found. Please provide a standard .pptx presentation.');
  }

  const parser = new DOMParser();
  const presXmlText = await presFile.async('string');
  const presDoc = parser.parseFromString(presXmlText, 'application/xml');

  // Check XML parser errors
  const parseError = presDoc.querySelector('parsererror');
  if (parseError) {
    throw new Error('Could not parse PowerPoint presentation structure.');
  }

  // 1. Get Slide Dimensions
  let widthEmu = DEFAULT_WIDTH_EMU;
  let heightEmu = DEFAULT_HEIGHT_EMU;
  const sldSz = presDoc.querySelector('sldSz');
  if (sldSz) {
    const cx = parseInt(sldSz.getAttribute('cx') || '', 10);
    const cy = parseInt(sldSz.getAttribute('cy') || '', 10);
    if (!isNaN(cx) && cx > 0) widthEmu = cx;
    if (!isNaN(cy) && cy > 0) heightEmu = cy;
  }

  // 2. Discover Slides from presentation relationships
  const relsFile = zip.file('ppt/_rels/presentation.xml.rels');
  const relsMap = new Map<string, string>();
  if (relsFile) {
    const relsText = await relsFile.async('string');
    const relsDoc = parser.parseFromString(relsText, 'application/xml');
    const relElements = relsDoc.querySelectorAll('Relationship');
    relElements.forEach((el) => {
      const id = el.getAttribute('Id');
      const target = el.getAttribute('Target');
      if (id && target) {
        // Target can be 'slides/slide1.xml' or '/ppt/slides/slide1.xml'
        let cleanTarget = target.startsWith('/') ? target.slice(1) : target;
        if (!cleanTarget.startsWith('ppt/')) {
          cleanTarget = 'ppt/' + cleanTarget;
        }
        relsMap.set(id, cleanTarget);
      }
    });
  }

  // Get slide order from sldIdLst
  const slidePaths: string[] = [];
  const sldIdLst = presDoc.querySelectorAll('sldIdLst > sldId');
  sldIdLst.forEach((el) => {
    const rId = el.getAttribute('r:id') || el.getAttribute('id');
    if (rId && relsMap.has(rId)) {
      slidePaths.push(relsMap.get(rId)!);
    }
  });

  // Fallback: search zip directly for ppt/slides/slide*.xml if sldIdLst was empty
  if (slidePaths.length === 0) {
    const foundPaths: string[] = [];
    zip.forEach((relativePath) => {
      if (/^ppt\/slides\/slide\d+\.xml$/i.test(relativePath)) {
        foundPaths.push(relativePath);
      }
    });
    // Sort numerically slide1, slide2, slide3...
    foundPaths.sort((a, b) => {
      const numA = parseInt(a.match(/slide(\d+)\.xml/i)?.[1] || '0', 10);
      const numB = parseInt(b.match(/slide(\d+)\.xml/i)?.[1] || '0', 10);
      return numA - numB;
    });
    slidePaths.push(...foundPaths);
  }

  if (slidePaths.length === 0) {
    throw new Error('No slides found in this PowerPoint presentation.');
  }

  // 3. Pre-extract media files (images)
  const mediaBlobMap = new Map<string, string>();
  const mediaPromises: Promise<void>[] = [];
  zip.forEach((relativePath, fileEntry) => {
    if (relativePath.startsWith('ppt/media/') && !fileEntry.dir) {
      mediaPromises.push(
        fileEntry.async('blob').then((blob) => {
          const mime = getMimeTypeFromExt(relativePath);
          const blobWithMime = new Blob([blob], { type: mime });
          const url = URL.createObjectURL(blobWithMime);
          mediaBlobMap.set(relativePath, url);
          // Also set without ppt/ prefix
          mediaBlobMap.set(relativePath.replace(/^ppt\//, ''), url);
        })
      );
    }
  });
  await Promise.all(mediaPromises);

  // 4. Parse each slide
  const slides: SlideItem[] = [];

  for (let i = 0; i < slidePaths.length; i++) {
    const slidePath = slidePaths[i];
    const slideFile = zip.file(slidePath);
    if (!slideFile) continue;

    const slideXmlText = await slideFile.async('string');
    const slideDoc = parser.parseFromString(slideXmlText, 'application/xml');

    // Parse slide relationships (for embedded images)
    // ppt/slides/_rels/slide1.xml.rels
    const slideRelsPath = slidePath.replace('ppt/slides/', 'ppt/slides/_rels/') + '.rels';
    const slideRelsFile = zip.file(slideRelsPath);
    const slideRelsMap = new Map<string, string>();
    if (slideRelsFile) {
      const sRelsText = await slideRelsFile.async('string');
      const sRelsDoc = parser.parseFromString(sRelsText, 'application/xml');
      sRelsDoc.querySelectorAll('Relationship').forEach((r) => {
        const id = r.getAttribute('Id');
        const target = r.getAttribute('Target');
        if (id && target) {
          // Normalize relative target like '../media/image1.png' -> 'ppt/media/image1.png'
          let resolved = target;
          if (resolved.startsWith('../media/')) {
            resolved = 'ppt/media/' + resolved.slice(9);
          } else if (resolved.startsWith('media/')) {
            resolved = 'ppt/media/' + resolved.slice(6);
          }
          const blobUrl = mediaBlobMap.get(resolved) || mediaBlobMap.get(resolved.replace(/^ppt\//, ''));
          if (blobUrl) {
            slideRelsMap.set(id, blobUrl);
          }
        }
      });
    }

    const pptxSlide = parseSingleSlide(slideDoc, i + 1, widthEmu, heightEmu, slideRelsMap);

    slides.push({
      id: `pptx-slide-${i + 1}`,
      index: i,
      slideNumber: i + 1,
      type: 'pptx',
      title: pptxSlide.title || `Slide ${i + 1}`,
      pptxData: pptxSlide,
    });
  }

  return {
    id: `pptx-${Date.now()}`,
    fileName: fileName || 'Presentation.pptx',
    fileType: 'pptx',
    totalSlides: slides.length,
    slides,
    rawArrayBuffer: arrayBuffer,
    createdAt: Date.now(),
  };
}

function parseSingleSlide(
  doc: Document,
  slideNumber: number,
  slideWidthEmu: number,
  slideHeightEmu: number,
  relsMap: Map<string, string>
): PptxSlideData {
  // Background detection
  let backgroundColor = '#0f172a'; // clean dark presentation default
  const bg = doc.querySelector('bg, p\\:bg');
  if (bg) {
    const srgbClr = bg.querySelector('srgbClr, a\\:srgbClr');
    if (srgbClr) {
      const val = srgbClr.getAttribute('val');
      if (val) backgroundColor = `#${val}`;
    }
  }

  const shapes: PptxShape[] = [];
  let slideTitle = '';

  // Extract regular shapes & text boxes
  const spNodes = doc.querySelectorAll('sp, p\\:sp');
  spNodes.forEach((sp, idx) => {
    const parsed = parseShape(sp, `sp-${slideNumber}-${idx}`, slideWidthEmu, slideHeightEmu);
    if (parsed) {
      shapes.push(parsed);
      // Check if this is the slide title
      const isTitlePh = sp.querySelector('ph[type="title"], ph[type="ctrTitle"]');
      if (isTitlePh && parsed.text && !slideTitle) {
        slideTitle = parsed.text;
      }
    }
  });

  // Extract pictures
  const picNodes = doc.querySelectorAll('pic, p\\:pic');
  picNodes.forEach((pic, idx) => {
    const parsed = parsePicture(pic, `pic-${slideNumber}-${idx}`, slideWidthEmu, slideHeightEmu, relsMap);
    if (parsed) {
      shapes.push(parsed);
    }
  });

  // Extract tables
  const graphicFrames = doc.querySelectorAll('graphicFrame, p\\:graphicFrame');
  graphicFrames.forEach((frame, idx) => {
    const parsed = parseTable(frame, `tbl-${slideNumber}-${idx}`, slideWidthEmu, slideHeightEmu);
    if (parsed) {
      shapes.push(parsed);
    }
  });

  // If no explicit title placeholder was found, use the first non-empty text shape
  if (!slideTitle) {
    for (const sh of shapes) {
      if (sh.text && sh.text.trim().length > 0) {
        slideTitle = sh.text.trim().split('\n')[0];
        break;
      }
    }
  }

  return {
    slideNumber,
    width: slideWidthEmu,
    height: slideHeightEmu,
    backgroundColor,
    shapes,
    title: slideTitle || `Slide ${slideNumber}`,
  };
}

function parseShape(
  sp: Element,
  id: string,
  slideWidthEmu: number,
  slideHeightEmu: number
): PptxShape | null {
  const xfrm = sp.querySelector('xfrm, a\\:xfrm');
  let x = 0, y = 0, width = 100, height = 50;

  if (xfrm) {
    const off = xfrm.querySelector('off, a\\:off');
    const ext = xfrm.querySelector('ext, a\\:ext');
    if (off && ext) {
      const offX = parseInt(off.getAttribute('x') || '0', 10);
      const offY = parseInt(off.getAttribute('y') || '0', 10);
      const extX = parseInt(ext.getAttribute('cx') || '0', 10);
      const extY = parseInt(ext.getAttribute('cy') || '0', 10);

      x = (offX / slideWidthEmu) * 100;
      y = (offY / slideHeightEmu) * 100;
      width = (extX / slideWidthEmu) * 100;
      height = (extY / slideHeightEmu) * 100;
    }
  }

  // Parse fill color
  let fillColor: string | undefined;
  const solidFill = sp.querySelector('spPr > solidFill, spPr > a\\:solidFill, a\\:spPr > a\\:solidFill');
  if (solidFill) {
    const srgb = solidFill.querySelector('srgbClr, a\\:srgbClr');
    if (srgb) {
      fillColor = '#' + (srgb.getAttribute('val') || 'ffffff');
    }
  }

  // Parse text
  const txBody = sp.querySelector('txBody, p\\:txBody');
  const paragraphs: PptxShape['paragraphs'] = [];
  let fullText = '';

  if (txBody) {
    const pNodes = txBody.querySelectorAll('p, a\\:p');
    pNodes.forEach((p) => {
      let paraText = '';
      let isBullet = false;
      const pPr = p.querySelector('pPr, a\\:pPr');
      let align: 'left' | 'center' | 'right' = 'left';
      if (pPr) {
        const al = pPr.getAttribute('algn');
        if (al === 'ctr') align = 'center';
        else if (al === 'r') align = 'right';
        if (pPr.querySelector('buChar, buAutoNum, a\\:buChar, a\\:buAutoNum')) {
          isBullet = true;
        }
      }

      let fontSize = 18;
      let bold = false;
      let italic = false;
      let color = '#f8fafc'; // light text for dark mode

      const rNodes = p.querySelectorAll('r, a\\:r');
      rNodes.forEach((r) => {
        const tNode = r.querySelector('t, a\\:t');
        if (tNode && tNode.textContent) {
          paraText += tNode.textContent;
        }
        const rPr = r.querySelector('rPr, a\\:rPr');
        if (rPr) {
          const sz = rPr.getAttribute('sz');
          if (sz) {
            fontSize = Math.round(parseInt(sz, 10) / 100);
          }
          if (rPr.getAttribute('b') === '1') bold = true;
          if (rPr.getAttribute('i') === '1') italic = true;
          const srgb = rPr.querySelector('srgbClr, a\\:srgbClr');
          if (srgb) {
            color = '#' + (srgb.getAttribute('val') || 'ffffff');
          }
        }
      });

      // If no r tags, check direct t tags
      if (!paraText) {
        const tNodes = p.querySelectorAll('t, a\\:t');
        tNodes.forEach((t) => {
          if (t.textContent) paraText += t.textContent;
        });
      }

      if (paraText.trim().length > 0) {
        paragraphs.push({
          text: paraText,
          fontSize,
          bold,
          italic,
          color,
          align,
          isBullet,
        });
        fullText += (fullText ? '\n' : '') + paraText;
      }
    });
  }

  // If there's neither text nor explicit geometry/fill, skip empty placeholder
  if (!fullText && !fillColor && width < 2 && height < 2) {
    return null;
  }

  return {
    id,
    x: Math.max(0, Math.min(100, x)),
    y: Math.max(0, Math.min(100, y)),
    width: Math.min(100, width),
    height: Math.min(100, height),
    fillColor,
    text: fullText,
    paragraphs,
    shapeType: 'text',
  };
}

function parsePicture(
  pic: Element,
  id: string,
  slideWidthEmu: number,
  slideHeightEmu: number,
  relsMap: Map<string, string>
): PptxShape | null {
  const xfrm = pic.querySelector('xfrm, a\\:xfrm');
  let x = 0, y = 0, width = 50, height = 40;

  if (xfrm) {
    const off = xfrm.querySelector('off, a\\:off');
    const ext = xfrm.querySelector('ext, a\\:ext');
    if (off && ext) {
      const offX = parseInt(off.getAttribute('x') || '0', 10);
      const offY = parseInt(off.getAttribute('y') || '0', 10);
      const extX = parseInt(ext.getAttribute('cx') || '0', 10);
      const extY = parseInt(ext.getAttribute('cy') || '0', 10);

      x = (offX / slideWidthEmu) * 100;
      y = (offY / slideHeightEmu) * 100;
      width = (extX / slideWidthEmu) * 100;
      height = (extY / slideHeightEmu) * 100;
    }
  }

  const blip = pic.querySelector('blip, a\\:blip');
  let imageUrl: string | undefined;
  if (blip) {
    const embedId = blip.getAttribute('r:embed');
    if (embedId && relsMap.has(embedId)) {
      imageUrl = relsMap.get(embedId);
    }
  }

  return {
    id,
    x: Math.max(0, Math.min(100, x)),
    y: Math.max(0, Math.min(100, y)),
    width: Math.min(100, width),
    height: Math.min(100, height),
    isImage: true,
    imageUrl,
    shapeType: 'image',
  };
}

function parseTable(
  frame: Element,
  id: string,
  slideWidthEmu: number,
  slideHeightEmu: number
): PptxShape | null {
  const tbl = frame.querySelector('tbl, a\\:tbl');
  if (!tbl) return null;

  const xfrm = frame.querySelector('xfrm, a\\:xfrm');
  let x = 10, y = 20, width = 80, height = 60;
  if (xfrm) {
    const off = xfrm.querySelector('off, a\\:off');
    const ext = xfrm.querySelector('ext, a\\:ext');
    if (off && ext) {
      const offX = parseInt(off.getAttribute('x') || '0', 10);
      const offY = parseInt(off.getAttribute('y') || '0', 10);
      const extX = parseInt(ext.getAttribute('cx') || '0', 10);
      const extY = parseInt(ext.getAttribute('cy') || '0', 10);
      x = (offX / slideWidthEmu) * 100;
      y = (offY / slideHeightEmu) * 100;
      width = (extX / slideWidthEmu) * 100;
      height = (extY / slideHeightEmu) * 100;
    }
  }

  const tableRows: string[][] = [];
  tbl.querySelectorAll('tr, a\\:tr').forEach((tr) => {
    const rowData: string[] = [];
    tr.querySelectorAll('tc, a\\:tc').forEach((tc) => {
      let cellText = '';
      tc.querySelectorAll('t, a\\:t').forEach((t) => {
        if (t.textContent) cellText += t.textContent;
      });
      rowData.push(cellText.trim());
    });
    if (rowData.length > 0) tableRows.push(rowData);
  });

  return {
    id,
    x: Math.max(0, Math.min(100, x)),
    y: Math.max(0, Math.min(100, y)),
    width: Math.min(100, width),
    height: Math.min(100, height),
    shapeType: 'table',
    tableRows,
  };
}

function getMimeTypeFromExt(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase();
  switch (ext) {
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'gif':
      return 'image/gif';
    case 'svg':
      return 'image/svg+xml';
    case 'webp':
      return 'image/webp';
    default:
      return 'application/octet-stream';
  }
}

/**
 * Creates a valid, real OpenXML .pptx presentation file using JSZip
 * for rapid testing of PPTX features in the browser!
 */
export async function createSamplePptx(): Promise<File> {
  const zip = new JSZip();

  // 1. [Content_Types].xml
  zip.file(
    '[Content_Types].xml',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  <Override PartName="/ppt/slides/slide1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
  <Override PartName="/ppt/slides/slide2.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
  <Override PartName="/ppt/slides/slide3.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
</Types>`
  );

  // 2. _rels/.rels
  zip.file(
    '_rels/.rels',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>`
  );

  // 3. ppt/presentation.xml
  zip.file(
    'ppt/presentation.xml',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
                xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
                xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:sldSz cx="12192000" cy="6858000" type="screen16x9"/>
  <p:sldIdLst>
    <p:sldId id="256" r:id="rId1"/>
    <p:sldId id="257" r:id="rId2"/>
    <p:sldId id="258" r:id="rId3"/>
  </p:sldIdLst>
</p:presentation>`
  );

  // 4. ppt/_rels/presentation.xml.rels
  zip.file(
    'ppt/_rels/presentation.xml.rels',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide3.xml"/>
</Relationships>`
  );

  // Helper for slide XML
  const makeSlideXml = (title: string, subtitle: string, bullets: string[]) => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
       xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
       xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld>
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>
      <!-- Title Shape -->
      <p:sp>
        <p:nvSpPr>
          <p:cNvPr id="2" name="Title 1"/>
          <p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>
          <p:nvPr><p:ph type="title"/></p:nvPr>
        </p:nvSpPr>
        <p:spPr>
          <a:xfrm><a:off x="1000000" y="800000"/><a:ext cx="10192000" cy="1400000"/></a:xfrm>
        </p:spPr>
        <p:txBody>
          <a:bodyPr/>
          <a:p>
            <a:pPr algn="l"/>
            <a:r>
              <a:rPr sz="4000" b="1"><a:srgbClr val="38BDF8"/></a:rPr>
              <a:t>${title}</a:t>
            </a:r>
          </a:p>
          <a:p>
            <a:pPr algn="l"/>
            <a:r>
              <a:rPr sz="2000"><a:srgbClr val="94A3B8"/></a:rPr>
              <a:t>${subtitle}</a:t>
            </a:r>
          </a:p>
        </p:txBody>
      </p:sp>
      <!-- Content Bullets Shape -->
      <p:sp>
        <p:nvSpPr>
          <p:cNvPr id="3" name="Content 1"/>
          <p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>
          <p:nvPr><p:ph type="body"/></p:nvPr>
        </p:nvSpPr>
        <p:spPr>
          <a:xfrm><a:off x="1000000" y="2600000"/><a:ext cx="10192000" cy="3600000"/></a:xfrm>
        </p:spPr>
        <p:txBody>
          <a:bodyPr/>
          ${bullets
            .map(
              (b) => `<a:p>
            <a:pPr algn="l"><a:buChar char="•"/></a:pPr>
            <a:r>
              <a:rPr sz="2200"><a:srgbClr val="F8FAFC"/></a:rPr>
              <a:t>${b}</a:t>
            </a:r>
          </a:p>`
            )
            .join('')}
        </p:txBody>
      </p:sp>
    </p:spTree>
  </p:cSld>
</p:sld>`;

  zip.file(
    'ppt/slides/slide1.xml',
    makeSlideXml(
      'Quarterly Performance Overview',
      'Real PowerPoint (.pptx) Imported in GesturePilot AI',
      [
        'Total Audience Reach increased by 42% over baseline',
        'Presenter mobility expanded with hands-free navigation',
        'Sub-second slide transition response time',
        'Native OOXML parsing running 100% client-side'
      ]
    )
  );

  zip.file(
    'ppt/slides/slide2.xml',
    makeSlideXml(
      'Touchless Control Architecture',
      'Zero-Latency Hand Mesh & Deterministic Gestures',
      [
        'Open Palm advances to slide 3',
        'V Sign navigates back to slide 1',
        'Index Finger Up triggers instant black screen toggle',
        'Thumbs Up / Fist manages presentation mode'
      ]
    )
  );

  zip.file(
    'ppt/slides/slide3.xml',
    makeSlideXml(
      'Conclusion & Next Steps',
      'Tested with Real .pptx OOXML Archives',
      [
        'Ready for boardroom keynotes and lecture halls',
        'True slide count verified: exactly 3 slides in this archive',
        'Supports rich shape geometries, paragraphs, and colors',
        'Presenter remains in complete control'
      ]
    )
  );

  const content = await zip.generateAsync({ type: 'blob' });
  return new File([content], 'Sample-PowerPoint-Deck.pptx', {
    type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  });
}
