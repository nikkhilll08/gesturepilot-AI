import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';
import { GestureType, GestureDetectionState } from '../types/presentation';

export interface Landmark {
  x: number;
  y: number;
  z?: number;
}

export type GestureCallback = (gesture: GestureType) => void;
export type StateCallback = (state: GestureDetectionState) => void;

const HOLD_REQUIRED_MS = 600; // ~600ms stable hold required
const COOLDOWN_MS = 800; // ~800ms cooldown after action

export class GestureEngine {
  private handLandmarker: HandLandmarker | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private canvasElement: HTMLCanvasElement | null = null;
  private animationFrameId: number | null = null;
  private isRunning: boolean = false;
  private isModelLoading: boolean = false;
  private initError: string | null = null;

  // Gesture state tracking
  private currentDetectedGesture: GestureType = 'NONE';
  private candidateGesture: GestureType = 'NONE';
  private candidateStartTime: number = 0;
  private cooldownUntil: number = 0;
  private waitingForNeutralRelease: boolean = false;
  private lastTriggeredGesture: GestureType | null = null;
  private lastTriggeredTime: number = 0;

  // Smoothing
  private smoothedConfidence: number = 0;

  // Listeners
  private onTriggerCallback: GestureCallback | null = null;
  private onStateChangeCallback: StateCallback | null = null;

  constructor() {}

  public setOnTrigger(cb: GestureCallback) {
    this.onTriggerCallback = cb;
  }

  public setOnStateChange(cb: StateCallback) {
    this.onStateChangeCallback = cb;
  }

  public async initialize(): Promise<void> {
    if (this.handLandmarker) return;
    if (this.isModelLoading) return;

    this.isModelLoading = true;
    this.initError = null;

    try {
      const vision = await FilesetResolver.forVisionTasks(
        'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm'
      );

      // Try GPU delegate first, fallback to CPU
      try {
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath:
              'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
            delegate: 'GPU',
          },
          runningMode: 'VIDEO',
          numHands: 1,
        });
      } catch (gpuErr) {
        console.warn('GPU acceleration unavailable for HandLandmarker, using CPU fallback:', gpuErr);
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath:
              'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
            delegate: 'CPU',
          },
          runningMode: 'VIDEO',
          numHands: 1,
        });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to load MediaPipe model';
      this.initError = msg;
      console.error('HandLandmarker initialization failed:', msg);
      throw new Error(msg);
    } finally {
      this.isModelLoading = false;
    }
  }

  public start(video: HTMLVideoElement, canvas: HTMLCanvasElement) {
    this.videoElement = video;
    this.canvasElement = canvas;
    this.isRunning = true;
    this.runDetectionLoop();
  }

  public stop() {
    this.isRunning = false;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    this.clearCanvas();
    this.updateState('NONE', 0, 0, false, false, 0);
  }

  private clearCanvas() {
    if (!this.canvasElement) return;
    const ctx = this.canvasElement.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);
    }
  }

  private runDetectionLoop = () => {
    if (!this.isRunning) return;

    const video = this.videoElement;
    const canvas = this.canvasElement;
    const now = performance.now();

    if (
      video &&
      canvas &&
      this.handLandmarker &&
      video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA &&
      video.videoWidth > 0
    ) {
      // Ensure canvas matches video size
      if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
      }

      try {
        const detectionResult = this.handLandmarker.detectForVideo(video, now);
        const ctx = canvas.getContext('2d');

        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
        }

        if (detectionResult && detectionResult.landmarks && detectionResult.landmarks.length > 0) {
          const landmarks = detectionResult.landmarks[0];

          // 1. Classify the gesture from 21 landmarks
          const { gesture, confidence } = this.classifyGesture(landmarks);
          this.currentDetectedGesture = gesture;
          this.smoothedConfidence = this.smoothedConfidence * 0.7 + confidence * 0.3;

          // 2. Process hold time, release latch, and cooldown
          const { isTriggered, holdProgress, isInCooldown, cooldownProgress } = this.processGestureTiming(gesture, now);

          // 3. Draw hand skeleton, landmarks, and trigger pulse onto canvas
          if (ctx) {
            this.drawHandOverlay(ctx, landmarks, canvas.width, canvas.height, gesture, holdProgress, isInCooldown);
          }

          // 4. Fire trigger callback if gesture has completed hold
          if (isTriggered && this.onTriggerCallback) {
            this.onTriggerCallback(gesture);
          }

          // 5. Emit state updates
          this.updateState(
            gesture,
            this.smoothedConfidence,
            holdProgress,
            isInCooldown,
            true,
            cooldownProgress
          );
        } else {
          // No hand in view
          this.currentDetectedGesture = 'NONE';
          this.candidateGesture = 'NONE';
          this.candidateStartTime = 0;
          this.waitingForNeutralRelease = false;

          const isInCooldown = now < this.cooldownUntil;
          const cooldownProgress = isInCooldown ? (this.cooldownUntil - now) / COOLDOWN_MS : 0;

          this.updateState('NONE', 0, 0, isInCooldown, false, cooldownProgress);
        }
      } catch (err) {
        // Suppress frame drop errors
      }
    }

    this.animationFrameId = requestAnimationFrame(this.runDetectionLoop);
  };

  /**
   * Evaluates the 21 landmarks geometrically to determine gesture
   */
  public classifyGesture(landmarks: Landmark[]): { gesture: GestureType; confidence: number } {
    if (landmarks.length < 21) {
      return { gesture: 'NONE', confidence: 0 };
    }

    const wrist = landmarks[0];

    // Helper for Euclidean distance
    const dist = (p1: Landmark, p2: Landmark) =>
      Math.hypot(p1.x - p2.x, p1.y - p2.y, (p1.z || 0) - (p2.z || 0));

    // Landmark references
    const thumbCmc = landmarks[1];
    const thumbMcp = landmarks[2];
    const thumbIp = landmarks[3];
    const thumbTip = landmarks[4];

    const indexMcp = landmarks[5];
    const indexPip = landmarks[6];
    const indexDip = landmarks[7];
    const indexTip = landmarks[8];

    const middleMcp = landmarks[9];
    const middlePip = landmarks[10];
    const middleDip = landmarks[11];
    const middleTip = landmarks[12];

    const ringMcp = landmarks[13];
    const ringPip = landmarks[14];
    const ringDip = landmarks[15];
    const ringTip = landmarks[16];

    const pinkyMcp = landmarks[17];
    const pinkyPip = landmarks[18];
    const pinkyDip = landmarks[19];
    const pinkyTip = landmarks[20];

    // 1. Determine finger extension status
    // For index, middle, ring, pinky:
    // Extended if tip distance from wrist is noticeably greater than PIP distance,
    // and tip is higher than PIP (tip.y < pip.y in screen space)
    const isIndexExtended =
      dist(indexTip, wrist) > dist(indexPip, wrist) * 1.15 &&
      indexTip.y < indexPip.y;

    const isMiddleExtended =
      dist(middleTip, wrist) > dist(middlePip, wrist) * 1.15 &&
      middleTip.y < middlePip.y;

    const isRingExtended =
      dist(ringTip, wrist) > dist(ringPip, wrist) * 1.15 &&
      ringTip.y < ringPip.y;

    const isPinkyExtended =
      dist(pinkyTip, wrist) > dist(pinkyPip, wrist) * 1.15 &&
      pinkyTip.y < pinkyPip.y;

    // Strict folded checks:
    // Tip curled in towards palm or lower than knuckle/pip
    const isIndexFolded = !isIndexExtended || indexTip.y >= indexPip.y - 0.02;
    const isMiddleFolded = !isMiddleExtended || middleTip.y >= middlePip.y - 0.02;
    const isRingFolded = !isRingExtended || ringTip.y >= ringPip.y - 0.02;
    const isPinkyFolded = !isPinkyExtended || pinkyTip.y >= pinkyPip.y - 0.02;

    // Thumb states:
    // Is thumb pointing UP (for Thumbs Up)?
    // Thumb tip is noticeably higher than thumb MCP, wrist, and higher than folded index knuckle
    const isThumbPointingUp =
      thumbTip.y < thumbMcp.y - 0.07 &&
      thumbTip.y < wrist.y - 0.12 &&
      thumbTip.y < indexMcp.y;

    // Is thumb extended outward from the hand (for Open Palm)?
    const isThumbExtendedOut =
      dist(thumbTip, indexMcp) > 0.12 &&
      dist(thumbTip, wrist) > dist(thumbMcp, wrist) * 1.15;

    // Is thumb curled / tucked against palm?
    const isThumbFolded = !isThumbPointingUp && !isThumbExtendedOut;

    // -------------------------------------------------------------
    // GESTURE 1: INDEX FINGER POINTING UP (Toggle Black Screen)
    // Only index finger extended, with thumb and other three fingers folded.
    // -------------------------------------------------------------
    if (
      isIndexExtended &&
      indexTip.y < indexPip.y - 0.05 &&
      indexTip.y < indexMcp.y - 0.1 &&
      isMiddleFolded &&
      isRingFolded &&
      isPinkyFolded &&
      !isThumbPointingUp
    ) {
      // Calculate confidence based on index protrusion over other fingers
      const heightAdvantage = middleTip.y - indexTip.y;
      const confidence = Math.min(1.0, Math.max(0.7, 0.7 + heightAdvantage * 2));
      return { gesture: 'INDEX_POINTING_UP', confidence };
    }

    // -------------------------------------------------------------
    // GESTURE 2: V SIGN (Previous Slide / Page)
    // Index and middle fingers extended in a V shape.
    // Ring, pinky, and thumb folded.
    // -------------------------------------------------------------
    if (
      isIndexExtended &&
      isMiddleExtended &&
      isRingFolded &&
      isPinkyFolded &&
      !isThumbPointingUp
    ) {
      // Check separation between index and middle tips (V shape)
      const tipDistance = dist(indexTip, middleTip);
      const isSeparated = tipDistance > 0.035;
      const confidence = isSeparated ? 0.95 : 0.8;
      return { gesture: 'V_SIGN', confidence };
    }

    // -------------------------------------------------------------
    // GESTURE 3: THUMBS UP (Enter Presentation Mode)
    // Thumb extended pointing up, index, middle, ring, pinky folded in fist.
    // -------------------------------------------------------------
    if (
      isThumbPointingUp &&
      isIndexFolded &&
      isMiddleFolded &&
      isRingFolded &&
      isPinkyFolded
    ) {
      return { gesture: 'THUMBS_UP', confidence: 0.95 };
    }

    // -------------------------------------------------------------
    // GESTURE 4: CLOSED FIST (Exit Presentation Mode)
    // All fingers folded, thumb folded/tucked across fingers, not pointing up.
    // -------------------------------------------------------------
    if (
      isIndexFolded &&
      isMiddleFolded &&
      isRingFolded &&
      isPinkyFolded &&
      !isThumbPointingUp
    ) {
      // Ensure hand is closed (tips close to palm/wrist)
      const maxFingerDist = Math.max(
        dist(indexTip, wrist),
        dist(middleTip, wrist),
        dist(ringTip, wrist),
        dist(pinkyTip, wrist)
      );
      const isTightFist = maxFingerDist < 0.35;
      return { gesture: 'CLOSED_FIST', confidence: isTightFist ? 0.95 : 0.82 };
    }

    // -------------------------------------------------------------
    // GESTURE 5: OPEN PALM (Next Slide / Page)
    // All 4 fingers extended outward and spread/open, thumb extended.
    // -------------------------------------------------------------
    if (
      isIndexExtended &&
      isMiddleExtended &&
      isRingExtended &&
      isPinkyExtended
    ) {
      return { gesture: 'OPEN_PALM', confidence: 0.95 };
    }

    // Transition / Neutral pose
    return { gesture: 'NEUTRAL', confidence: 0.5 };
  }

  /**
   * Implements ~600ms hold requirement, ~800ms cooldown, and neutral release latch
   */
  private processGestureTiming(gesture: GestureType, now: number): {
    isTriggered: boolean;
    holdProgress: number;
    isInCooldown: boolean;
    cooldownProgress: number;
  } {
    // Check if in cooldown
    const isInCooldown = now < this.cooldownUntil;
    const cooldownProgress = isInCooldown ? Math.max(0, (this.cooldownUntil - now) / COOLDOWN_MS) : 0;

    if (isInCooldown) {
      this.candidateGesture = 'NONE';
      this.candidateStartTime = 0;
      return { isTriggered: false, holdProgress: 0, isInCooldown: true, cooldownProgress };
    }

    // Check if waiting for neutral release
    if (this.waitingForNeutralRelease) {
      if (gesture === 'NEUTRAL' || gesture === 'NONE') {
        // Hand neutralized! Re-arm recognition
        this.waitingForNeutralRelease = false;
        this.candidateGesture = 'NONE';
        this.candidateStartTime = 0;
      }
      return { isTriggered: false, holdProgress: 0, isInCooldown: false, cooldownProgress: 0 };
    }

    // Only actionable gestures require hold
    const isActionable =
      gesture === 'OPEN_PALM' ||
      gesture === 'V_SIGN' ||
      gesture === 'THUMBS_UP' ||
      gesture === 'CLOSED_FIST' ||
      gesture === 'INDEX_POINTING_UP';

    if (!isActionable) {
      this.candidateGesture = 'NONE';
      this.candidateStartTime = 0;
      return { isTriggered: false, holdProgress: 0, isInCooldown: false, cooldownProgress: 0 };
    }

    // Track stability
    if (this.candidateGesture !== gesture) {
      this.candidateGesture = gesture;
      this.candidateStartTime = now;
      return { isTriggered: false, holdProgress: 0.05, isInCooldown: false, cooldownProgress: 0 };
    }

    const elapsed = now - this.candidateStartTime;
    const holdProgress = Math.min(1.0, elapsed / HOLD_REQUIRED_MS);

    if (elapsed >= HOLD_REQUIRED_MS) {
      // TRIGGER ACTION!
      this.cooldownUntil = now + COOLDOWN_MS;
      this.waitingForNeutralRelease = true; // Must release or neutralize hand before next trigger
      this.lastTriggeredGesture = gesture;
      this.lastTriggeredTime = now;
      this.candidateGesture = 'NONE';
      this.candidateStartTime = 0;

      return { isTriggered: true, holdProgress: 1.0, isInCooldown: true, cooldownProgress: 1.0 };
    }

    return { isTriggered: false, holdProgress, isInCooldown: false, cooldownProgress: 0 };
  }

  /**
   * Draws the hand skeleton and landmarks onto the video canvas
   */
  private drawHandOverlay(
    ctx: CanvasRenderingContext2D,
    landmarks: Landmark[],
    width: number,
    height: number,
    gesture: GestureType,
    holdProgress: number,
    isInCooldown: boolean
  ) {
    const connections: [number, number][] = [
      // Thumb
      [0, 1], [1, 2], [2, 3], [3, 4],
      // Index
      [0, 5], [5, 6], [6, 7], [7, 8],
      // Middle
      [5, 9], [9, 10], [10, 11], [11, 12],
      // Ring
      [9, 13], [13, 14], [14, 15], [15, 16],
      // Pinky
      [13, 17], [17, 18], [18, 19], [19, 20],
      // Base
      [0, 17],
    ];

    // Glow effect
    ctx.save();

    const isRecognized =
      gesture !== 'NONE' && gesture !== 'NEUTRAL';

    let strokeColor = 'rgba(148, 163, 184, 0.4)'; // slate default
    let dotColor = '#94a3b8';

    if (isInCooldown) {
      strokeColor = 'rgba(234, 179, 8, 0.5)'; // yellow
      dotColor = '#eab308';
    } else if (isRecognized) {
      strokeColor = 'rgba(56, 189, 248, 0.7)'; // electric sky blue
      dotColor = '#38bdf8';
      if (holdProgress > 0.8) {
        strokeColor = 'rgba(34, 197, 94, 0.9)'; // emerald trigger ready
        dotColor = '#22c55e';
      }
    }

    // Draw lines
    ctx.lineWidth = 3;
    ctx.strokeStyle = strokeColor;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    for (const [startIdx, endIdx] of connections) {
      const p1 = landmarks[startIdx];
      const p2 = landmarks[endIdx];
      ctx.beginPath();
      ctx.moveTo(p1.x * width, p1.y * height);
      ctx.lineTo(p2.x * width, p2.y * height);
      ctx.stroke();
    }

    // Draw joint dots
    landmarks.forEach((p, index) => {
      ctx.beginPath();
      const isTip = [4, 8, 12, 16, 20].includes(index);
      const radius = isTip ? 5 : 3.5;
      ctx.arc(p.x * width, p.y * height, radius, 0, Math.PI * 2);
      ctx.fillStyle = isTip ? '#ffffff' : dotColor;
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = dotColor;
      ctx.stroke();
    });

    // Draw hold progress ring around palm center (approx index 9 MCP or wrist)
    if (holdProgress > 0 && !isInCooldown) {
      const center = landmarks[9]; // middle MCP
      const cx = center.x * width;
      const cy = center.y * height;
      const ringRadius = 24;

      // Outer track
      ctx.beginPath();
      ctx.arc(cx, cy, ringRadius, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Progress arc
      ctx.beginPath();
      ctx.arc(
        cx,
        cy,
        ringRadius,
        -Math.PI / 2,
        -Math.PI / 2 + holdProgress * (Math.PI * 2)
      );
      ctx.strokeStyle = holdProgress >= 0.95 ? '#22c55e' : '#38bdf8';
      ctx.lineWidth = 4;
      ctx.stroke();
    }

    ctx.restore();
  }

  private updateState(
    detectedGesture: GestureType,
    confidence: number,
    holdProgress: number,
    isInCooldown: boolean,
    handInView: boolean,
    cooldownProgress: number
  ) {
    if (this.onStateChangeCallback) {
      this.onStateChangeCallback({
        detectedGesture,
        activeGesture: this.candidateGesture !== 'NONE' ? this.candidateGesture : detectedGesture,
        confidence,
        holdProgress,
        isHolding: holdProgress > 0 && holdProgress < 1,
        isInCooldown,
        cooldownProgress,
        waitingForNeutralRelease: this.waitingForNeutralRelease,
        handInView,
        lastTriggeredGesture: this.lastTriggeredGesture,
        lastTriggeredTime: this.lastTriggeredTime,
      });
    }
  }

  /**
   * Manual gesture trigger helper (for quick simulated testing)
   */
  public triggerManualGesture(gesture: GestureType) {
    this.lastTriggeredGesture = gesture;
    this.lastTriggeredTime = performance.now();
    if (this.onTriggerCallback) {
      this.onTriggerCallback(gesture);
    }
  }
}

export const gestureEngine = new GestureEngine();
