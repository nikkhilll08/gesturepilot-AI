import React from 'react';
import { X, Sparkles, Shield, Clock, RotateCcw } from 'lucide-react';
import { GESTURE_DEFINITIONS } from '../types/presentation';

interface GestureGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GestureGuideModal: React.FC<GestureGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const gestures = [
    GESTURE_DEFINITIONS.OPEN_PALM,
    GESTURE_DEFINITIONS.V_SIGN,
    GESTURE_DEFINITIONS.THUMBS_UP,
    GESTURE_DEFINITIONS.CLOSED_FIST,
    GESTURE_DEFINITIONS.INDEX_POINTING_UP,
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              Five-Gesture Control Guide
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Control slides touchlessly using computer vision in your browser
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Gesture Cards Grid */}
        <div className="p-6 overflow-y-auto space-y-3.5">
          {gestures.map((item, idx) => (
            <div
              key={idx}
              className="flex items-start gap-4 p-4 rounded-xl bg-slate-800/40 border border-slate-700/60 hover:border-slate-600 transition-colors"
            >
              <div className="w-12 h-12 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl shrink-0">
                {item.symbol}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-sm font-semibold text-white">
                    {idx + 1}. {item.name}
                  </h3>
                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-sky-950/60 text-sky-400 border border-sky-800/40">
                    {item.action}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mb-1.5">
                  {item.description}
                </p>
                <p className="text-[11px] text-slate-400">
                  <strong className="text-slate-300">Hand Pose:</strong> {item.fingerRule}
                </p>
              </div>
            </div>
          ))}

          {/* Technical Specs & Timing Rules */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800/80">
            <div className="p-3 rounded-lg bg-slate-800/30 border border-slate-800 flex items-start gap-2.5">
              <Clock className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-semibold text-white">600ms Hold</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Hold pose steadily for ~600ms to trigger the action.
                </div>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/30 border border-slate-800 flex items-start gap-2.5">
              <RotateCcw className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-semibold text-white">Neutral Release</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Release hand to neutral before repeating any gesture.
                </div>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/30 border border-slate-800 flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-semibold text-white">100% Local</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  No video leaves your device. Complete client privacy.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
