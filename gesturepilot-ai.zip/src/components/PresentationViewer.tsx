import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  FileText,
  Upload,
  HelpCircle,
  Moon,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Square,
} from 'lucide-react';
import { PresentationDocument, GestureType } from '../types/presentation';
import { SlideRenderer } from './SlideRenderer';
import { BlackScreenOverlay } from './BlackScreenOverlay';
import { WebcamHUD } from './WebcamHUD';
import { GestureGuideModal } from './GestureGuideModal';
import { soundService } from '../services/soundService';

interface PresentationViewerProps {
  document: PresentationDocument;
  onChangeFile: () => void;
}

export const PresentationViewer: React.FC<PresentationViewerProps> = ({
  document,
  onChangeFile,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);
  const [isPresentationMode, setIsPresentationMode] = useState<boolean>(false);
  const [isBlackScreen, setIsBlackScreen] = useState<boolean>(false);
  const [isGuideOpen, setIsGuideOpen] = useState<boolean>(false);
  const [gestureFeedbackToast, setGestureFeedbackToast] = useState<{
    text: string;
    symbol: string;
    time: number;
  } | null>(null);

  const containerRef = useRef<HTMLDivElement | null>(null);

  const totalSlides = document.totalSlides || document.slides.length;
  const currentSlide = document.slides[currentSlideIndex] || document.slides[0];

  // Navigation handlers
  const goToNextSlide = useCallback(() => {
    // If black screen is active, do NOT change slides
    if (isBlackScreen) return;
    setCurrentSlideIndex((prev) => {
      if (prev < totalSlides - 1) {
        soundService.playNextSlide();
        return prev + 1;
      }
      return prev;
    });
  }, [totalSlides, isBlackScreen]);

  const goToPrevSlide = useCallback(() => {
    // If black screen is active, do NOT change slides
    if (isBlackScreen) return;
    setCurrentSlideIndex((prev) => {
      if (prev > 0) {
        soundService.playPrevSlide();
        return prev - 1;
      }
      return prev;
    });
  }, [isBlackScreen]);

  const togglePresentationMode = useCallback(() => {
    setIsPresentationMode((prev) => {
      const next = !prev;
      soundService.playModeToggle(next);
      return next;
    });
  }, []);

  const toggleBlackScreen = useCallback(() => {
    setIsBlackScreen((prev) => {
      const nextState = !prev;
      soundService.playBlackScreenToggle(nextState);
      return nextState;
    });
  }, []);

  // Show transient toast on gesture actions
  const showGestureToast = (symbol: string, text: string) => {
    setGestureFeedbackToast({ symbol, text, time: Date.now() });
    setTimeout(() => {
      setGestureFeedbackToast((curr) => (curr && Date.now() - curr.time >= 1800 ? null : curr));
    }, 2000);
  };

  // -------------------------------------------------------------
  // GESTURE ACTION ROUTER
  // -------------------------------------------------------------
  const handleGestureTrigger = useCallback(
    (gesture: GestureType) => {
      switch (gesture) {
        case 'OPEN_PALM':
          // Move to next slide or PDF page
          if (!isBlackScreen) {
            goToNextSlide();
            showGestureToast('✋', 'Next Slide (Open Palm)');
          }
          break;

        case 'V_SIGN':
          // Move to previous slide or PDF page
          if (!isBlackScreen) {
            goToPrevSlide();
            showGestureToast('✌️', 'Previous Slide (V Sign)');
          }
          break;

        case 'THUMBS_UP':
          // Enter presentation mode
          if (!isPresentationMode) {
            setIsPresentationMode(true);
            soundService.playModeToggle(true);
            showGestureToast('👍', 'Entered Presentation Mode (Thumbs Up)');
          }
          break;

        case 'CLOSED_FIST':
          // Exit presentation mode
          if (isPresentationMode) {
            setIsPresentationMode(false);
            soundService.playModeToggle(false);
            showGestureToast('✊', 'Exited Presentation Mode (Closed Fist)');
          }
          break;

        case 'INDEX_POINTING_UP':
          // Toggle black screen
          // Prompt requirement: "When the index-finger gesture is detected during presentation mode, display a completely black screen.
          // When the gesture is performed again after releasing or neutralizing the hand pose, restore the exact same slide or page.
          // Do not advance, go backward, or change the current slide while toggling the black screen.
          // Do not exit presentation mode when the black screen is activated."
          toggleBlackScreen();
          showGestureToast('☝️', isBlackScreen ? 'Slide Restored (Index Up)' : 'Black Screen Active (Index Up)');
          break;

        default:
          break;
      }
    },
    [isBlackScreen, isPresentationMode, goToNextSlide, goToPrevSlide, toggleBlackScreen]
  );

  // Keyboard navigation support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (e.key) {
        case 'ArrowRight':
        case 'PageDown':
        case ' ':
          e.preventDefault();
          goToNextSlide();
          break;

        case 'ArrowLeft':
        case 'PageUp':
          e.preventDefault();
          goToPrevSlide();
          break;

        case 'b':
        case 'B':
        case '.':
          e.preventDefault();
          toggleBlackScreen();
          break;

        case 'f':
        case 'F':
        case 'F5':
          e.preventDefault();
          togglePresentationMode();
          break;

        case 'Escape':
          if (isBlackScreen) {
            setIsBlackScreen(false);
          } else if (isPresentationMode) {
            setIsPresentationMode(false);
          }
          break;

        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goToNextSlide, goToPrevSlide, toggleBlackScreen, togglePresentationMode, isBlackScreen, isPresentationMode]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-screen bg-slate-950 text-slate-100 flex flex-col select-none overflow-hidden ${
        isPresentationMode ? 'presentation-mode' : ''
      }`}
    >
      {/* -------------------------------------------------------------
          TOP BAR (Quiet, minimalist, adheres to Top Bar Contract)
      ------------------------------------------------------------- */}
      {!isPresentationMode && (
        <header className="flex items-center justify-between gap-4 px-4 sm:px-6 py-3 border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm z-30 shrink-0">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3">
            <span className="text-base font-bold text-white tracking-tight whitespace-nowrap">
              GesturePilot AI
            </span>
            <span className="hidden md:inline-block text-xs text-slate-500 font-mono">
              /
            </span>
            <div className="hidden md:flex items-center gap-2 text-xs text-slate-400 truncate max-w-xs sm:max-w-md">
              <FileText className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="truncate font-medium">{document.fileName}</span>
            </div>
          </div>

          {/* Zone 2: Slide Count & Quick Navigation Indicator */}
          <div className="flex items-center gap-3">
            <div className="text-xs font-semibold text-slate-300 tabular-nums bg-slate-800/80 px-3 py-1 rounded-md border border-slate-700/60">
              Slide {currentSlideIndex + 1} of {totalSlides}
            </div>

            <button
              onClick={() => setIsGuideOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md border border-slate-700/60 transition-colors"
              title="Five-Gesture Reference Guide"
            >
              <HelpCircle className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">Gesture Guide</span>
            </button>
          </div>

          {/* Zone 3: Primary Action Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={onChangeFile}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors whitespace-nowrap"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Change File</span>
            </button>

            <button
              onClick={togglePresentationMode}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-lg shadow-sm transition-colors whitespace-nowrap"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Start Presentation</span>
            </button>
          </div>
        </header>
      )}

      {/* -------------------------------------------------------------
          MAIN PRESENTATION STAGE
      ------------------------------------------------------------- */}
      <main className="relative flex-1 w-full h-full flex items-center justify-center overflow-hidden bg-slate-950">
        {currentSlide && (
          <SlideRenderer
            slide={currentSlide}
            pdfDoc={document.pdfDoc}
            isFullscreen={isPresentationMode}
          />
        )}

        {/* Transient Gesture Feedback Notification */}
        {gestureFeedbackToast && (
          <div className="absolute top-6 z-40 pointer-events-none animate-bounce-subtle">
            <div className="flex items-center gap-2.5 px-4 py-2 rounded-full bg-slate-900/90 border border-slate-700/80 text-xs font-semibold text-white shadow-2xl backdrop-blur-md">
              <span className="text-base">{gestureFeedbackToast.symbol}</span>
              <span>{gestureFeedbackToast.text}</span>
            </div>
          </div>
        )}

        {/* Reversible Pitch-Black Screen Overlay */}
        <BlackScreenOverlay
          isActive={isBlackScreen}
          onDismiss={() => setIsBlackScreen(false)}
        />
      </main>

      {/* -------------------------------------------------------------
          BOTTOM CONTROLS BAR (Manual Navigation & Action Controls)
      ------------------------------------------------------------- */}
      <footer
        className={`px-4 sm:px-6 py-2.5 border-t border-slate-800/80 bg-slate-900/90 backdrop-blur-sm z-30 transition-all duration-300 ${
          isPresentationMode
            ? 'opacity-0 hover:opacity-100 focus-within:opacity-100 transition-opacity'
            : 'opacity-100'
        }`}
      >
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          {/* Left: Previous / Next Navigation Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={goToPrevSlide}
              disabled={currentSlideIndex === 0 || isBlackScreen}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none text-white border border-slate-700/60 transition-colors"
              title="Previous Slide (V Sign ✌️ or Left Arrow)"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              onClick={goToNextSlide}
              disabled={currentSlideIndex >= totalSlides - 1 || isBlackScreen}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none text-white border border-slate-700/60 transition-colors"
              title="Next Slide (Open Palm ✋ or Right Arrow)"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <span className="text-xs text-slate-500 font-mono ml-2 tabular-nums">
              {currentSlideIndex + 1} / {totalSlides}
            </span>
          </div>

          {/* Center: Slide Scrub Bar */}
          <div className="hidden md:flex items-center gap-1.5 max-w-sm w-full mx-4">
            {document.slides.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlideIndex(idx)}
                className={`h-1.5 rounded-full transition-all flex-1 ${
                  idx === currentSlideIndex
                    ? 'bg-sky-400'
                    : 'bg-slate-800 hover:bg-slate-700'
                }`}
                title={`Jump to slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Right: Mode & Tool Controls */}
          <div className="flex items-center gap-2">
            {/* Toggle Black Screen Button */}
            <button
              onClick={toggleBlackScreen}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                isBlackScreen
                  ? 'bg-sky-950 text-sky-300 border-sky-700'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700/60'
              }`}
              title="Toggle Black Screen (Index Finger Up ☝️ or press 'B')"
            >
              <Moon className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">Black Screen</span>
            </button>

            {/* Presentation Mode Toggle */}
            <button
              onClick={togglePresentationMode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white border border-slate-700/60 transition-colors"
              title={
                isPresentationMode
                  ? 'Exit Presentation Mode (Closed Fist ✊ or Esc)'
                  : 'Enter Presentation Mode (Thumbs Up 👍)'
              }
            >
              {isPresentationMode ? (
                <>
                  <Minimize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Exit Mode</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Present</span>
                </>
              )}
            </button>
          </div>
        </div>
      </footer>

      {/* -------------------------------------------------------------
          FLOATING WEBCAM HUD & REAL-TIME GESTURE CONTROLLER
      ------------------------------------------------------------- */}
      <WebcamHUD
        onGestureTrigger={handleGestureTrigger}
        isPresentationMode={isPresentationMode}
        isBlackScreen={isBlackScreen}
      />

      {/* -------------------------------------------------------------
          FIVE-GESTURE REFERENCE GUIDE MODAL
      ------------------------------------------------------------- */}
      <GestureGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
      />
    </div>
  );
};
