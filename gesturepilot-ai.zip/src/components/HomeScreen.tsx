import React, { useState, useRef } from 'react';
import {
  Upload,
  Play,
  FileText,
  Shield,
  Sparkles,
  Camera,
  AlertCircle,
  FileCode,
  FileSpreadsheet,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import { PresentationDocument, GESTURE_DEFINITIONS } from '../types/presentation';
import { parsePptxFile, createSamplePptx } from '../services/pptxService';
import { parsePdfFile, createSamplePdf } from '../services/pdfService';
import { createDemoPresentation } from '../services/demoPresentation';
import { GestureGuideModal } from './GestureGuideModal';

interface HomeScreenProps {
  onDocumentLoaded: (doc: PresentationDocument) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onDocumentLoaded }) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [isGuideOpen, setIsGuideOpen] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const gestures = [
    GESTURE_DEFINITIONS.OPEN_PALM,
    GESTURE_DEFINITIONS.V_SIGN,
    GESTURE_DEFINITIONS.THUMBS_UP,
    GESTURE_DEFINITIONS.CLOSED_FIST,
    GESTURE_DEFINITIONS.INDEX_POINTING_UP,
  ];

  const handleFileSelection = async (file: File) => {
    setErrorMessage(null);
    const fileName = file.name;
    const lowerName = fileName.toLowerCase();

    if (lowerName.endsWith('.ppt') && !lowerName.endsWith('.pptx')) {
      setErrorMessage(
        'Legacy binary PowerPoint (.ppt) format is not supported. Please save or export your presentation as .pptx or .pdf.'
      );
      return;
    }

    if (!lowerName.endsWith('.pptx') && !lowerName.endsWith('.pdf')) {
      setErrorMessage(
        'Unsupported file format. Please choose a PowerPoint (.pptx) or PDF (.pdf) presentation.'
      );
      return;
    }

    setIsLoading(true);
    try {
      if (lowerName.endsWith('.pptx')) {
        setLoadingMessage('Parsing PowerPoint slides and media assets...');
        const doc = await parsePptxFile(file, fileName);
        onDocumentLoaded(doc);
      } else if (lowerName.endsWith('.pdf')) {
        setLoadingMessage('Initializing PDF.js engine and vector pages...');
        const doc = await parsePdfFile(file, fileName);
        onDocumentLoaded(doc);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to parse presentation file.';
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelection(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileSelection(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const loadDemo = () => {
    setIsLoading(true);
    setLoadingMessage('Loading interactive 4-slide demo...');
    setTimeout(() => {
      const demo = createDemoPresentation();
      onDocumentLoaded(demo);
      setIsLoading(false);
    }, 200);
  };

  const loadSamplePptxDeck = async () => {
    setIsLoading(true);
    setLoadingMessage('Generating real OOXML PowerPoint (.pptx) deck...');
    try {
      const samplePptx = await createSamplePptx();
      const doc = await parsePptxFile(samplePptx, samplePptx.name);
      onDocumentLoaded(doc);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error generating sample PPTX';
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const loadSamplePdfDeck = async () => {
    setIsLoading(true);
    setLoadingMessage('Generating sample PDF deck...');
    try {
      const samplePdf = await createSamplePdf();
      const doc = await parsePdfFile(samplePdf, samplePdf.name);
      onDocumentLoaded(doc);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error generating sample PDF';
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-sky-500 selection:text-white">
      {/* Top Header */}
      <header className="flex items-center justify-between gap-8 px-6 lg:px-12 py-5 border-b border-slate-800/80 bg-slate-900/40 backdrop-blur-sm">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <span className="text-xl font-extrabold tracking-tight text-white whitespace-nowrap">
            GesturePilot AI
          </span>
          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-sky-950/80 text-sky-400 border border-sky-800/50">
            Vision Controller
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => setIsGuideOpen(true)}
            className="hover:text-white transition-colors whitespace-nowrap"
          >
            Five-Gesture Guide
          </button>
          <span className="text-slate-700">·</span>
          <span className="text-slate-400 whitespace-nowrap">PowerPoint & PDF Native</span>
          <span className="text-slate-700">·</span>
          <span className="text-slate-400 whitespace-nowrap">100% Client-Side Privacy</span>
        </nav>

        {/* Zone 3: Primary CTA button */}
        <div className="flex items-center gap-3">
          <button
            onClick={loadDemo}
            className="px-4 py-2 text-xs font-semibold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors whitespace-nowrap"
          >
            Try Demo
          </button>
        </div>
      </header>

      {/* Main Hero & Upload Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-6 py-10 lg:py-16 flex flex-col justify-center space-y-12">
        {/* Hero Copy */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight">
            GesturePilot AI
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 font-normal max-w-2xl mx-auto">
            Control your presentations with simple hand gestures.
          </p>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
            Zero-hardware touchless slide navigation for PowerPoint (.pptx) and PDF presentations powered by client-side computer vision.
          </p>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="max-w-xl mx-auto w-full p-4 rounded-xl bg-rose-950/50 border border-rose-800/80 flex items-start gap-3 text-rose-200">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="text-xs sm:text-sm leading-relaxed">
              <strong className="font-semibold block text-rose-100 mb-0.5">
                File Error
              </strong>
              {errorMessage}
            </div>
          </div>
        )}

        {/* Upload Drop Zone & Primary Actions */}
        <div className="max-w-2xl mx-auto w-full">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileInputChange}
            accept=".pptx,.pdf"
            className="hidden"
          />

          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
            className={`p-8 sm:p-10 rounded-2xl border-2 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center text-center group ${
              isDragOver
                ? 'border-sky-400 bg-sky-950/20 scale-[1.01]'
                : 'border-slate-800 hover:border-slate-700 bg-slate-900/50 hover:bg-slate-900/80'
            }`}
          >
            <div className="w-14 h-14 rounded-xl bg-slate-800 group-hover:bg-sky-950 border border-slate-700 group-hover:border-sky-700 flex items-center justify-center text-sky-400 mb-4 transition-colors">
              <Upload className="w-7 h-7" />
            </div>

            <div className="space-y-1.5 mb-6">
              <h3 className="text-base font-semibold text-white">
                Drag and drop your presentation here
              </h3>
              <p className="text-xs text-slate-400">
                Supports PowerPoint (<span className="text-slate-300 font-mono">.pptx</span>) and Adobe PDF (<span className="text-slate-300 font-mono">.pdf</span>)
              </p>
            </div>

            {/* Main & Secondary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-sm justify-center">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                disabled={isLoading}
                className="w-full sm:w-auto px-6 py-2.5 rounded-lg text-sm font-semibold bg-sky-600 hover:bg-sky-500 text-white shadow-lg shadow-sky-950 transition-colors whitespace-nowrap"
              >
                Choose Presentation
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  loadDemo();
                }}
                disabled={isLoading}
                className="w-full sm:w-auto px-6 py-2.5 rounded-lg text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors whitespace-nowrap"
              >
                Try Demo
              </button>
            </div>

            {/* Quick Sample File Loaders */}
            <div className="pt-6 mt-6 border-t border-slate-800/80 flex items-center gap-3 text-xs text-slate-400">
              <span className="text-slate-400">Or test samples:</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  loadSamplePptxDeck();
                }}
                className="text-sky-400 hover:text-sky-300 underline font-medium"
              >
                Sample PPTX
              </button>
              <span className="text-slate-600">·</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  loadSamplePdfDeck();
                }}
                className="text-sky-400 hover:text-sky-300 underline font-medium"
              >
                Sample PDF
              </button>
            </div>
          </div>
        </div>

        {/* Loading Overlay */}
        {isLoading && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
            <div className="w-10 h-10 border-3 border-sky-400 border-t-transparent rounded-full animate-spin mb-4" />
            <h3 className="text-base font-semibold text-white">
              Loading Presentation...
            </h3>
            <p className="text-xs text-slate-400 mt-1">{loadingMessage}</p>
          </div>
        )}

        {/* Five Gestures Quick Reference Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide uppercase">
                Five Supported Hand Gestures
              </h2>
              <p className="text-xs text-slate-400">
                Engineered for natural touchless control with 600ms hold stabilization
              </p>
            </div>
            <button
              onClick={() => setIsGuideOpen(true)}
              className="text-xs text-sky-400 hover:text-sky-300 font-medium"
            >
              View Detailed Guide →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {gestures.map((item, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-colors flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="text-3xl mb-2">{item.symbol}</div>
                  <h3 className="text-xs font-bold text-white">
                    {item.name}
                  </h3>
                  <div className="text-[11px] font-semibold text-sky-400 mt-0.5">
                    {item.action}
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed border-t border-slate-800/60 pt-2">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="px-6 lg:px-12 py-6 border-t border-slate-800/80 bg-slate-900/30 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span>Local Privacy First: Video and slides are processed 100% in your browser.</span>
        </div>
        <div className="text-slate-400">
          GesturePilot AI · Presentation Controller
        </div>
      </footer>

      {/* Five-Gesture Reference Guide Modal */}
      <GestureGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
      />
    </div>
  );
};
