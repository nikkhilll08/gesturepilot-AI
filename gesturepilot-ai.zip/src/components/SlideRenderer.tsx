import React, { useEffect, useRef } from 'react';
import { SlideItem } from '../types/presentation';
import { renderPdfPageToCanvas } from '../services/pdfService';

interface SlideRendererProps {
  slide: SlideItem;
  pdfDoc?: any;
  isFullscreen?: boolean;
}

export const SlideRenderer: React.FC<SlideRendererProps> = ({
  slide,
  pdfDoc,
  isFullscreen = false,
}) => {
  const pdfCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Render PDF pages on slide change
  useEffect(() => {
    if (slide.type === 'pdf' && pdfDoc && pdfCanvasRef.current && slide.pdfPageIndex) {
      renderPdfPageToCanvas(pdfDoc, slide.pdfPageIndex, pdfCanvasRef.current);
    }
  }, [slide, pdfDoc]);

  // Handle PDF rendering
  if (slide.type === 'pdf') {
    return (
      <div className="relative w-full h-full flex items-center justify-center bg-slate-950 p-2 sm:p-6 overflow-hidden select-none">
        <div className="relative max-w-full max-h-full flex items-center justify-center shadow-2xl rounded-lg overflow-hidden border border-slate-800">
          <canvas
            ref={pdfCanvasRef}
            className="max-h-[82vh] w-auto object-contain bg-white transition-opacity duration-200"
          />
        </div>
      </div>
    );
  }

  // Handle PPTX rendering
  if (slide.type === 'pptx' && slide.pptxData) {
    const { shapes, backgroundColor } = slide.pptxData;

    return (
      <div className="relative w-full h-full flex items-center justify-center bg-slate-950 p-2 sm:p-6 select-none overflow-hidden">
        {/* 16:9 Presentation Canvas Container */}
        <div
          className="relative w-full max-w-6xl aspect-[16/9] max-h-[82vh] rounded-xl shadow-2xl overflow-hidden border border-slate-800"
          style={{ backgroundColor: backgroundColor || '#0f172a' }}
        >
          {shapes.map((shape) => {
            const style: React.CSSProperties = {
              position: 'absolute',
              left: `${shape.x}%`,
              top: `${shape.y}%`,
              width: `${shape.width}%`,
              height: `${shape.height}%`,
              backgroundColor: shape.fillColor || 'transparent',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
            };

            // Image Shape
            if (shape.isImage && shape.imageUrl) {
              return (
                <div key={shape.id} style={style} className="pointer-events-none">
                  <img
                    src={shape.imageUrl}
                    alt="Slide Graphic"
                    className="w-full h-full object-contain"
                  />
                </div>
              );
            }

            // Table Shape
            if (shape.shapeType === 'table' && shape.tableRows) {
              return (
                <div key={shape.id} style={style} className="p-2 overflow-auto">
                  <table className="w-full h-full text-xs sm:text-sm text-slate-200 border-collapse border border-slate-700">
                    <tbody>
                      {shape.tableRows.map((row, rIdx) => (
                        <tr key={rIdx} className="border-b border-slate-800">
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="p-2 border border-slate-700">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              );
            }

            // Text Shape
            return (
              <div key={shape.id} style={style} className="p-2 leading-relaxed">
                {shape.paragraphs && shape.paragraphs.length > 0 ? (
                  shape.paragraphs.map((para, pIdx) => (
                    <div
                      key={pIdx}
                      style={{
                        textAlign: para.align || 'left',
                        fontWeight: para.bold ? 700 : 400,
                        fontStyle: para.italic ? 'italic' : 'normal',
                        color: para.color || '#f8fafc',
                        fontSize: para.fontSize ? `${Math.max(13, Math.min(42, para.fontSize * 1.1))}px` : '18px',
                      }}
                      className={`leading-normal ${para.isBullet ? 'flex items-start gap-2.5 my-1.5' : 'my-1'}`}
                    >
                      {para.isBullet && (
                        <span className="text-sky-400 select-none">•</span>
                      )}
                      <span>{para.text}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-100 text-lg">{shape.text}</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Handle Demo slide rendering
  const demo = slide.demoData;
  if (!demo) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-slate-950 text-slate-400">
        Slide {slide.slideNumber}
      </div>
    );
  }

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-slate-950 p-2 sm:p-6 select-none overflow-hidden">
      {/* 16:9 Presentation Canvas */}
      <div
        className={`relative w-full max-w-6xl aspect-[16/9] max-h-[82vh] rounded-xl shadow-2xl overflow-hidden border border-slate-800/80 bg-slate-900 flex flex-col justify-between p-8 sm:p-12 md:p-14 ${
          isFullscreen ? 'scale-100' : ''
        }`}
      >
        {/* Subtle grid pattern background */}
        <div
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #ffffff 1px, transparent 0)`,
            backgroundSize: '32px 32px',
          }}
        />

        {/* Top Header metadata */}
        <div className="relative z-10 flex items-center justify-between border-b border-slate-800/60 pb-4">
          <div className="flex items-center gap-2.5 text-xs font-semibold tracking-wider text-sky-400 uppercase">
            <span>GesturePilot AI</span>
            <span className="text-slate-600">/</span>
            <span className="text-slate-400">{demo.category}</span>
          </div>
          <div className="text-xs font-medium text-slate-500 tabular-nums">
            Slide {slide.slideNumber} of 4
          </div>
        </div>

        {/* Main Content by Layout */}
        <div className="relative z-10 my-auto py-4">
          {demo.layout === 'title' && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-tight">
                  {demo.title}
                </h1>
                <p className="mt-3 text-lg sm:text-xl text-sky-300 font-medium">
                  {demo.subtitle}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                {demo.points?.map((pt, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50 space-y-1.5"
                  >
                    <h3 className="text-sm font-semibold text-white">{pt.heading}</h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {pt.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {demo.layout === 'problem' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight">
                  {demo.title}
                </h2>
                <p className="mt-2 text-sm sm:text-base text-slate-400 max-w-2xl">
                  {demo.subtitle}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {demo.cards?.map((card, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-lg bg-slate-800/40 border border-slate-700/60 hover:border-slate-600/80 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xl">{card.symbol}</span>
                      <span className="text-[11px] font-medium text-amber-400">
                        {card.badge}
                      </span>
                    </div>
                    <h3 className="text-base font-semibold text-white mb-1">
                      {card.title}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {card.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {demo.layout === 'solution' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight">
                  {demo.title}
                </h2>
                <p className="mt-2 text-sm sm:text-base text-slate-400 max-w-2xl">
                  {demo.subtitle}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {demo.cards?.map((card, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-lg bg-slate-800/40 border border-slate-700/60 hover:border-sky-500/40 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xl">{card.symbol}</span>
                      <span className="text-[11px] font-medium text-emerald-400">
                        {card.badge}
                      </span>
                    </div>
                    <h3 className="text-base font-semibold text-white mb-1">
                      {card.title}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {card.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {demo.layout === 'workflow' && (
            <div className="space-y-5">
              <div>
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight">
                  {demo.title}
                </h2>
                <p className="mt-1 text-sm text-slate-400 max-w-2xl">
                  {demo.subtitle}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-2">
                {demo.cards?.map((card, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg bg-slate-800/50 border border-slate-700/60 flex flex-col justify-between"
                  >
                    <div>
                      <div className="text-2xl mb-2">{card.symbol}</div>
                      <div className="text-xs font-semibold text-white mb-0.5">
                        {card.title}
                      </div>
                      <div className="text-[11px] font-medium text-sky-400 mb-2">
                        {card.badge}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-tight">
                      {card.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer note */}
        <div className="relative z-10 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-500">
          <span>{demo.footerNote}</span>
          <span className="hidden sm:inline">GesturePilot AI Presentation Engine</span>
        </div>
      </div>
    </div>
  );
};
