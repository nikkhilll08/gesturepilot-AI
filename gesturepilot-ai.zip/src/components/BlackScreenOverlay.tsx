import React, { useState, useEffect } from 'react';

interface BlackScreenOverlayProps {
  isActive: boolean;
  onDismiss: () => void;
}

export const BlackScreenOverlay: React.FC<BlackScreenOverlayProps> = ({
  isActive,
  onDismiss,
}) => {
  const [showHint, setShowHint] = useState(false);

  // Briefly show subtle hint on mouse movement or initial activation
  useEffect(() => {
    if (!isActive) return;

    let timer: number;
    const handleMouseMove = () => {
      setShowHint(true);
      window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        setShowHint(false);
      }, 2500);
    };

    window.addEventListener('mousemove', handleMouseMove);
    // Show hint for 3 seconds initially
    setShowHint(true);
    timer = window.setTimeout(() => {
      setShowHint(false);
    }, 3000);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.clearTimeout(timer);
    };
  }, [isActive]);

  if (!isActive) return null;

  return (
    <div
      onClick={onDismiss}
      className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-between p-8 select-none cursor-pointer"
      title="Click or use Index Finger gesture to restore slide"
    >
      <div />
      {/* Subtle indicator that fades away so screen is pitch black */}
      <div
        className={`transition-opacity duration-500 ease-out flex flex-col items-center gap-2 ${
          showHint ? 'opacity-80' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-2.5 px-4 py-2 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300 shadow-xl backdrop-blur-sm">
          <span className="text-sky-400">☝️</span>
          <span>Black Screen Active</span>
          <span className="text-slate-600">·</span>
          <span className="text-slate-400">
            Hold Index Finger Up (or press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono text-[11px]">B</kbd> / Click) to restore slide
          </span>
        </div>
      </div>
      <div />
    </div>
  );
};
