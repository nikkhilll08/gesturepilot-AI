import React, { useEffect, useRef, useState } from 'react';
import { Camera, CameraOff, Eye, EyeOff, RotateCcw, Volume2, VolumeX, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import { GestureType, GestureDetectionState, GESTURE_DEFINITIONS } from '../types/presentation';
import { gestureEngine } from '../services/gestureEngine';
import { soundService } from '../services/soundService';

interface WebcamHUDProps {
  onGestureTrigger: (gesture: GestureType) => void;
  isPresentationMode: boolean;
  isBlackScreen: boolean;
}

export const WebcamHUD: React.FC<WebcamHUDProps> = ({
  onGestureTrigger,
  isPresentationMode,
  isBlackScreen,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [isCameraActive, setIsCameraActive] = useState<boolean>(true);
  const [cameraPermissionError, setCameraPermissionError] = useState<string | null>(null);
  const [isModelReady, setIsModelReady] = useState<boolean>(false);
  const [isModelLoading, setIsModelLoading] = useState<boolean>(false);
  const [isSoundMuted, setIsSoundMuted] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);

  const [gestureState, setGestureState] = useState<GestureDetectionState>({
    detectedGesture: 'NONE',
    activeGesture: 'NONE',
    confidence: 0,
    holdProgress: 0,
    isHolding: false,
    isInCooldown: false,
    cooldownProgress: 0,
    waitingForNeutralRelease: false,
    handInView: false,
    lastTriggeredGesture: null,
    lastTriggeredTime: 0,
  });

  // Sound mute state sync
  useEffect(() => {
    soundService.enabled = !isSoundMuted;
  }, [isSoundMuted]);

  // Hook gesture engine callbacks
  useEffect(() => {
    gestureEngine.setOnTrigger((gesture) => {
      onGestureTrigger(gesture);
    });

    gestureEngine.setOnStateChange((state) => {
      setGestureState(state);
    });
  }, [onGestureTrigger]);

  // Start webcam and initialize MediaPipe
  useEffect(() => {
    let isMounted = true;

    async function initCameraAndVision() {
      if (!isCameraActive) {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop());
          streamRef.current = null;
        }
        gestureEngine.stop();
        return;
      }

      setCameraPermissionError(null);
      setIsModelLoading(true);

      try {
        // Request webcam
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: { ideal: 640 },
            height: { ideal: 480 },
            facingMode: 'user',
          },
          audio: false,
        });

        if (!isMounted) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }

        streamRef.current = stream;

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }

        // Initialize MediaPipe Tasks HandLandmarker
        await gestureEngine.initialize();
        if (isMounted) {
          setIsModelReady(true);
          setIsModelLoading(false);
          if (videoRef.current && canvasRef.current) {
            gestureEngine.start(videoRef.current, canvasRef.current);
          }
        }
      } catch (err: unknown) {
        if (!isMounted) return;
        setIsModelLoading(false);
        const errorMsg =
          err instanceof Error
            ? err.name === 'NotAllowedError'
              ? 'Webcam permission was denied. You can continue using manual buttons, or allow camera in browser settings.'
              : err.message
            : 'Could not access webcam device.';
        setCameraPermissionError(errorMsg);
      }
    }

    initCameraAndVision();

    return () => {
      isMounted = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      gestureEngine.stop();
    };
  }, [isCameraActive]);

  const activeDef = GESTURE_DEFINITIONS[gestureState.detectedGesture] || GESTURE_DEFINITIONS.NONE;
  const holdPercent = Math.round(gestureState.holdProgress * 100);

  return (
    <div
      className={`fixed bottom-4 right-4 z-40 transition-all duration-300 ${
        isMinimized ? 'w-64' : 'w-72 sm:w-80'
      }`}
    >
      <div className="bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${
                isCameraActive && isModelReady && gestureState.handInView
                  ? 'bg-emerald-400'
                  : isCameraActive && isModelReady
                  ? 'bg-amber-400'
                  : 'bg-slate-500'
              }`}
            />
            <span className="text-xs font-semibold text-white tracking-wide">
              Gesture Pilot HUD
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsSoundMuted(!isSoundMuted)}
              title={isSoundMuted ? 'Unmute Audio Chimes' : 'Mute Audio Chimes'}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              {isSoundMuted ? <VolumeX className="w-3.5 h-3.5 text-amber-400" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => setIsCameraActive(!isCameraActive)}
              title={isCameraActive ? 'Turn Off Camera' : 'Turn On Camera'}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              {isCameraActive ? <Camera className="w-3.5 h-3.5 text-sky-400" /> : <CameraOff className="w-3.5 h-3.5 text-rose-400" />}
            </button>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              title={isMinimized ? 'Expand Camera View' : 'Minimize View'}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              {isMinimized ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Video Stage (Hidden when Minimized) */}
        {!isMinimized && (
          <div className="relative aspect-[4/3] bg-black overflow-hidden group">
            {isCameraActive ? (
              <>
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  className="w-full h-full object-cover scale-x-[-1]" // mirrored
                />
                <canvas
                  ref={canvasRef}
                  className="absolute inset-0 w-full h-full pointer-events-none scale-x-[-1]"
                />

                {isModelLoading && (
                  <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center">
                    <div className="w-6 h-6 border-2 border-sky-400 border-t-transparent rounded-full animate-spin mb-2" />
                    <span className="text-xs text-slate-300 font-medium">Initializing MediaPipe Vision...</span>
                    <span className="text-[11px] text-slate-500 mt-1">Downloading neural hand mesh</span>
                  </div>
                )}

                {cameraPermissionError && (
                  <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-4 text-center">
                    <AlertCircle className="w-6 h-6 text-amber-400 mb-2" />
                    <span className="text-xs text-amber-200 font-medium">Camera Disabled</span>
                    <p className="text-[11px] text-slate-400 mt-1 max-w-[200px]">
                      {cameraPermissionError}
                    </p>
                  </div>
                )}
              </>
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 p-4 text-center">
                <CameraOff className="w-8 h-8 text-slate-600 mb-2" />
                <span className="text-xs text-slate-400 font-medium">Camera Paused</span>
                <span className="text-[11px] text-slate-600 mt-0.5">Click camera icon above to re-enable</span>
              </div>
            )}

            {/* Live Gesture Overlay Pill */}
            {isCameraActive && !cameraPermissionError && !isModelLoading && (
              <div className="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none">
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-950/80 border border-slate-700/60 backdrop-blur-sm text-[11px] font-medium shadow-md">
                  <span className="text-sm">{activeDef.symbol}</span>
                  <span className="text-slate-100">{activeDef.name}</span>
                </div>

                {gestureState.handInView && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono text-slate-400 bg-slate-950/80 border border-slate-800">
                    {Math.round(gestureState.confidence * 100)}%
                  </span>
                )}
              </div>
            )}
          </div>
        )}

        {/* Status & Timing Meters */}
        <div className="p-3 space-y-2.5 bg-slate-900">
          {/* Gesture Action Bar */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Action:</span>
            <span
              className={`font-semibold ${
                gestureState.detectedGesture === 'INDEX_POINTING_UP'
                  ? 'text-sky-300'
                  : gestureState.detectedGesture === 'OPEN_PALM'
                  ? 'text-emerald-300'
                  : gestureState.detectedGesture === 'V_SIGN'
                  ? 'text-indigo-300'
                  : gestureState.detectedGesture === 'THUMBS_UP'
                  ? 'text-amber-300'
                  : gestureState.detectedGesture === 'CLOSED_FIST'
                  ? 'text-rose-300'
                  : 'text-slate-500'
              }`}
            >
              {activeDef.action}
            </span>
          </div>

          {/* 600ms Hold Progress Indicator */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Hold Stability (~600ms)</span>
              <span className="font-mono tabular-nums text-slate-300">
                {gestureState.isInCooldown ? 'Cooldown' : `${holdPercent}%`}
              </span>
            </div>

            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-75 ${
                  gestureState.isInCooldown
                    ? 'bg-amber-400'
                    : holdPercent >= 90
                    ? 'bg-emerald-400'
                    : 'bg-sky-400'
                }`}
                style={{
                  width: gestureState.isInCooldown
                    ? `${Math.round(gestureState.cooldownProgress * 100)}%`
                    : `${holdPercent}%`,
                }}
              />
            </div>
          </div>

          {/* Neutral Release & Status Alerts */}
          {gestureState.waitingForNeutralRelease && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800/80 border border-slate-700/60 text-[11px] text-slate-300">
              <RotateCcw className="w-3 h-3 text-sky-400 animate-spin" />
              <span>Release pose to neutral to re-arm</span>
            </div>
          )}

          {gestureState.isInCooldown && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-amber-950/40 border border-amber-800/40 text-[11px] text-amber-300">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              <span>800ms trigger cooldown active</span>
            </div>
          )}

          {/* Quick Simulated Gestures (Great for testing without webcam) */}
          <div className="pt-1 border-t border-slate-800">
            <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1.5">
              Simulate Gesture
            </div>
            <div className="grid grid-cols-5 gap-1">
              <button
                onClick={() => gestureEngine.triggerManualGesture('OPEN_PALM')}
                title="Simulate Open Palm (Next Slide)"
                className="py-1 px-1 rounded bg-slate-800 hover:bg-slate-700 text-xs flex flex-col items-center justify-center text-slate-200 transition-colors"
              >
                <span>✋</span>
                <span className="text-[9px] text-slate-400 mt-0.5">Next</span>
              </button>
              <button
                onClick={() => gestureEngine.triggerManualGesture('V_SIGN')}
                title="Simulate V Sign (Previous Slide)"
                className="py-1 px-1 rounded bg-slate-800 hover:bg-slate-700 text-xs flex flex-col items-center justify-center text-slate-200 transition-colors"
              >
                <span>✌️</span>
                <span className="text-[9px] text-slate-400 mt-0.5">Prev</span>
              </button>
              <button
                onClick={() => gestureEngine.triggerManualGesture('THUMBS_UP')}
                title="Simulate Thumbs Up (Enter Presentation Mode)"
                className="py-1 px-1 rounded bg-slate-800 hover:bg-slate-700 text-xs flex flex-col items-center justify-center text-slate-200 transition-colors"
              >
                <span>👍</span>
                <span className="text-[9px] text-slate-400 mt-0.5">Present</span>
              </button>
              <button
                onClick={() => gestureEngine.triggerManualGesture('CLOSED_FIST')}
                title="Simulate Closed Fist (Exit Presentation Mode)"
                className="py-1 px-1 rounded bg-slate-800 hover:bg-slate-700 text-xs flex flex-col items-center justify-center text-slate-200 transition-colors"
              >
                <span>✊</span>
                <span className="text-[9px] text-slate-400 mt-0.5">Exit</span>
              </button>
              <button
                onClick={() => gestureEngine.triggerManualGesture('INDEX_POINTING_UP')}
                title="Simulate Index Finger Up (Toggle Black Screen)"
                className="py-1 px-1 rounded bg-slate-800 hover:bg-slate-700 text-xs flex flex-col items-center justify-center text-slate-200 transition-colors"
              >
                <span>☝️</span>
                <span className="text-[9px] text-slate-400 mt-0.5">Black</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
