import React, { useState } from 'react';
import { PresentationDocument } from './types/presentation';
import { HomeScreen } from './components/HomeScreen';
import { PresentationViewer } from './components/PresentationViewer';

export default function App() {
  const [currentDocument, setCurrentDocument] = useState<PresentationDocument | null>(null);

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 font-sans antialiased">
      {!currentDocument ? (
        <HomeScreen onDocumentLoaded={(doc) => setCurrentDocument(doc)} />
      ) : (
        <PresentationViewer
          document={currentDocument}
          onChangeFile={() => setCurrentDocument(null)}
        />
      )}
    </div>
  );
}
